<?php

namespace Transbank\Utils;

class ResponseCodesEnum
{
    const RESPONSE_CODE_APPROVED = 0;
}
