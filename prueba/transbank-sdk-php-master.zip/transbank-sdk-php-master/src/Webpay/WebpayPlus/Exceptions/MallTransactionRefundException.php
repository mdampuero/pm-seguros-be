<?php

namespace Transbank\Webpay\WebpayPlus\Exceptions;

class MallTransactionRefundException extends TransactionRefundException
{
}
