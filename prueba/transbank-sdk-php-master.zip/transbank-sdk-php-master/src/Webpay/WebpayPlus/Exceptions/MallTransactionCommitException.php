<?php

namespace Transbank\Webpay\WebpayPlus\Exceptions;

class MallTransactionCommitException extends TransactionCommitException
{
}
