<?php

namespace Transbank\Webpay\WebpayPlus\Exceptions;

class MallTransactionCreateException extends TransactionCreateException
{
}
