<?php

namespace Transbank\Webpay\WebpayPlus\Exceptions;

class MallTransactionCaptureException extends TransactionCaptureException
{
}
