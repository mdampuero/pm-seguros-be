<?php

namespace Transbank\Webpay\WebpayPlus\Exceptions;

class MallTransactionStatusException extends TransactionStatusException
{
}
