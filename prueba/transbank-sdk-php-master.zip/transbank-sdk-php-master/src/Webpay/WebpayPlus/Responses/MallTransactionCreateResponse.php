<?php

namespace Transbank\Webpay\WebpayPlus\Responses;

class MallTransactionCreateResponse extends TransactionCreateResponse
{
}
