<?php

namespace Transbank\Webpay\WebpayPlus\Responses;

class MallTransactionRefundResponse extends TransactionRefundResponse
{
}
