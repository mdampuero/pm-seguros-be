<?php

namespace Transbank\Webpay\WebpayPlus\Responses;

class MallTransactionCommitResponse extends MallTransactionStatusResponse
{
}
