<?php

namespace Transbank\Webpay\WebpayPlus\Responses;

class MallTransactionCaptureResponse extends TransactionCaptureResponse
{
}
