<?php

namespace Transbank\Webpay\WebpayPlus\Responses;

class TransactionCommitResponse extends TransactionStatusResponse
{
}
