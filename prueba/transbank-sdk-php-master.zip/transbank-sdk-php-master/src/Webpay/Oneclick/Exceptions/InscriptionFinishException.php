<?php

namespace Transbank\Webpay\Oneclick\Exceptions;

use Transbank\Webpay\Exceptions\WebpayRequestException;

class InscriptionFinishException extends WebpayRequestException
{
}
