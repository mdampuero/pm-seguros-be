<?php

namespace Transbank\Webpay\Oneclick\Exceptions;

use Transbank\Webpay\Exceptions\WebpayRequestException;

class MallTransactionCaptureException extends WebpayRequestException
{
}
