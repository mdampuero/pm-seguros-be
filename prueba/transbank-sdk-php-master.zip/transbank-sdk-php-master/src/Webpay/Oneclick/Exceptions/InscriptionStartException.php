<?php

namespace Transbank\Webpay\Oneclick\Exceptions;

use Transbank\Webpay\Exceptions\WebpayRequestException;

class InscriptionStartException extends WebpayRequestException
{
}
