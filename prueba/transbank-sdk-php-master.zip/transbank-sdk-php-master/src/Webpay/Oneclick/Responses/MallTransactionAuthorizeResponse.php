<?php

namespace Transbank\Webpay\Oneclick\Responses;

class MallTransactionAuthorizeResponse extends MallTransactionStatusResponse
{
}
