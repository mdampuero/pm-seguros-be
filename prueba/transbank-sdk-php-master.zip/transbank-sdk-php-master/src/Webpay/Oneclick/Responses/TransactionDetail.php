<?php

namespace Transbank\Webpay\Oneclick\Responses;

class TransactionDetail extends \Transbank\Webpay\WebpayPlus\Responses\TransactionDetail
{
}
