<?php

namespace Transbank\Webpay\Modal\Exceptions;

use Transbank\Webpay\Exceptions\WebpayRequestException;

class TransactionCreateException extends WebpayRequestException
{
}
