<?php

namespace Transbank\Webpay\Modal\Exceptions;

use Transbank\Webpay\Exceptions\WebpayRequestException;

class TransactionStatusException extends WebpayRequestException
{
}
