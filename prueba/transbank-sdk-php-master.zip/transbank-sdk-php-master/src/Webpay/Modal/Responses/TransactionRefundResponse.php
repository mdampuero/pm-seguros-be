<?php

namespace Transbank\Webpay\Modal\Responses;

class TransactionRefundResponse extends \Transbank\Webpay\WebpayPlus\Responses\TransactionRefundResponse
{
}
