<?php

namespace Transbank\Webpay\Modal\Responses;

class TransactionCommitResponse extends TransactionStatusResponse
{
}
