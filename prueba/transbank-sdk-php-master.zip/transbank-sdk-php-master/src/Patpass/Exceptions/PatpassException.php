<?php

namespace Transbank\Patpass\Exceptions;

use Transbank\Webpay\Exceptions\WebpayRequestException;

class PatpassException extends WebpayRequestException
{
}
