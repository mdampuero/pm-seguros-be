<?php

namespace Transbank\Patpass\PatpassByWebpay\Responses;

class TransactionStatusResponse extends \Transbank\Webpay\WebpayPlus\Responses\TransactionStatusResponse
{
}
