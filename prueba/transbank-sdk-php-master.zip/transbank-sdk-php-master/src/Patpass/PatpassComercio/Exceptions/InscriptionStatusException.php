<?php

/**
 * Class InscriptionStatusException.
 *
 * @category
 */

namespace Transbank\Patpass\PatpassComercio\Exceptions;

use Transbank\Patpass\Exceptions\PatpassException;

class InscriptionStatusException extends PatpassException
{
}
