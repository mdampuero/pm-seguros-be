<?php

/**
 * Class InscriptionStartException.
 *
 * @category
 */

namespace Transbank\Patpass\PatpassComercio\Exceptions;

use Transbank\PatPass\Exceptions\PatpassException;

class InscriptionStartException extends PatpassException
{
}
