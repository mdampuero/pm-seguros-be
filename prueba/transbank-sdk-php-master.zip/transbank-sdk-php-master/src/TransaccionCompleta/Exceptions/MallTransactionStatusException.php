<?php

namespace Transbank\TransaccionCompleta\Exceptions;

class MallTransactionStatusException extends MallTransactionCompletaException
{
}
