<?php

namespace Transbank\TransaccionCompleta\Exceptions;

class TransactionRefundException extends TransaccionCompletaException
{
}
