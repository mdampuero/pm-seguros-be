<?php

namespace Transbank\TransaccionCompleta\Exceptions;

use Transbank\Webpay\Exceptions\WebpayRequestException;

class MallTransactionCompletaException extends WebpayRequestException
{
}
