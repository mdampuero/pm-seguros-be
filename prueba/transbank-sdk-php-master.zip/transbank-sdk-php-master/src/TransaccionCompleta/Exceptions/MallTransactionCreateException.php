<?php

namespace Transbank\TransaccionCompleta\Exceptions;

class MallTransactionCreateException extends MallTransactionCompletaException
{
}
