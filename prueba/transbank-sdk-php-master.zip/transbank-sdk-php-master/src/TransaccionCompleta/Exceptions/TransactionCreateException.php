<?php

namespace Transbank\TransaccionCompleta\Exceptions;

class TransactionCreateException extends TransaccionCompletaException
{
}
