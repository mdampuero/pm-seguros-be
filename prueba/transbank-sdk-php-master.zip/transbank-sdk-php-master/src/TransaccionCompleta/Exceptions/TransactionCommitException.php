<?php

namespace Transbank\TransaccionCompleta\Exceptions;

class TransactionCommitException extends TransaccionCompletaException
{
}
