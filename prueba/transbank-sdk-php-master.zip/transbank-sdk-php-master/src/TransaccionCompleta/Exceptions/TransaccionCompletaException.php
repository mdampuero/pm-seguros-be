<?php

namespace Transbank\TransaccionCompleta\Exceptions;

use Transbank\Webpay\Exceptions\WebpayRequestException;

class TransaccionCompletaException extends WebpayRequestException
{
}
