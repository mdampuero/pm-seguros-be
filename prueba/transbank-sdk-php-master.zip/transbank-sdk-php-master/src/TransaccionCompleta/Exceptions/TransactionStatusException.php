<?php

namespace Transbank\TransaccionCompleta\Exceptions;

class TransactionStatusException extends TransaccionCompletaException
{
}
