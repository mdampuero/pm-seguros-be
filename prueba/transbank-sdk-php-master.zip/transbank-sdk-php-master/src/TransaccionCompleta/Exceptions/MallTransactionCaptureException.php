<?php

namespace Transbank\TransaccionCompleta\Exceptions;

class MallTransactionCaptureException extends MallTransactionCompletaException
{
}
