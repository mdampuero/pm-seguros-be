<?php

namespace Transbank\TransaccionCompleta\Exceptions;

class MallTransactionInstallmentsException extends MallTransactionCompletaException
{
}
