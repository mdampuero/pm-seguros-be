<?php

namespace Transbank\TransaccionCompleta\Exceptions;

class TransactionCaptureException extends TransaccionCompletaException
{
}
