<?php

namespace Transbank\TransaccionCompleta\Exceptions;

class TransactionInstallmentsException extends TransaccionCompletaException
{
}
