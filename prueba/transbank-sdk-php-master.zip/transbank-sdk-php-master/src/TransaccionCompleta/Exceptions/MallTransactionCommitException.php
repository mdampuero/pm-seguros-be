<?php

namespace Transbank\TransaccionCompleta\Exceptions;

class MallTransactionCommitException extends MallTransactionCompletaException
{
}
