<?php

namespace Transbank\TransaccionCompleta\Exceptions;

class MallTransactionRefundException extends MallTransactionCompletaException
{
}
