<?php

namespace Transbank\TransaccionCompleta\Responses;

class MallTransactionCommitResponse extends MallTransactionStatusResponse
{
}
