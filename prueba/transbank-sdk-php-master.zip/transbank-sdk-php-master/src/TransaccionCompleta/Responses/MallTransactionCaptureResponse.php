<?php

namespace Transbank\TransaccionCompleta\Responses;

class MallTransactionCaptureResponse extends TransactionCaptureResponse
{
}
