<?php

namespace Transbank\TransaccionCompleta\Responses;

class TransactionCaptureResponse extends \Transbank\Webpay\WebpayPlus\Responses\TransactionCaptureResponse
{
}
