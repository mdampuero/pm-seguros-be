<?php

namespace Transbank\TransaccionCompleta\Responses;

class TransactionCommitResponse extends TransactionStatusResponse
{
}
