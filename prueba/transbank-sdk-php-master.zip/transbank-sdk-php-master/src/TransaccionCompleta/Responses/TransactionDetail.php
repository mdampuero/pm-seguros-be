<?php

namespace Transbank\TransaccionCompleta\Responses;

class TransactionDetail extends \Transbank\Webpay\WebpayPlus\Responses\TransactionDetail
{
}
